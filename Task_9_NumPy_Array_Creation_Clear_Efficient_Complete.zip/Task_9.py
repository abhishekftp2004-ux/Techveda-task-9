import numpy as np

# 1D and 2D arrays
one_d = np.array([10,20,30,40,50])
two_d = np.array([[10,20,30],[40,50,60]])

print("1D:", one_d)
print("Shape:", one_d.shape, "Dimensions:", one_d.ndim, "Size:", one_d.size, "Type:", one_d.dtype)
print("\n2D:\n", two_d)
print("Shape:", two_d.shape, "Dimensions:", two_d.ndim, "Size:", two_d.size, "Type:", two_d.dtype)

# Data types
integer_array = np.array([1,2,3], dtype=np.int32)
float_array = np.array([1,2,3], dtype=np.float64)
print("\nInteger dtype:", integer_array.dtype)
print("Float dtype:", float_array.dtype)

# Student marks and numerical operations
marks = np.array([72,85,91,64,78])
print("\nMarks:", marks)
print("Marks + 5:", marks+5)
print("Average:", marks.mean())
print("Maximum:", marks.max())
print("Minimum:", marks.min())

# Indexing and slicing
print("First mark:", marks[0])
print("First three:", marks[:3])

# Array creation functions
print("\nZeros:\n", np.zeros((2,3)))
print("Ones:\n", np.ones((2,3)))
print("Range:", np.arange(0,10,2))

# Iris-style sample
iris = np.array([[5.1,3.5,1.4,0.2],[6.2,3.4,5.4,2.3],[5.9,3.0,4.2,1.5]])
print("\nIris shape:", iris.shape)
print("Column means:", iris.mean(axis=0))
